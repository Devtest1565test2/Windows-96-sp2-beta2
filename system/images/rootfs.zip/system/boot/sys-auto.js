// system reserved
// make your own JS file to create code for startup

/*
 * Move "Social" folder to "Network"
 */

const fs = w96.FS;

const OLD_PATH = 'C:/system/programs/Social';
const NEW_PATH = 'C:/system/programs/Network';
const MV_LOCK = 'social_mv.lock';

if(fs.exists(OLD_PATH) && !localStorage.getItem(MV_LOCK)) {
	fs.readdir(OLD_PATH).forEach(oldPath => {
		const newPath = NEW_PATH + oldPath.replace(OLD_PATH, '');
		
		if(!fs.exists(newPath))
			fs.mvfile(oldPath, newPath);
	});

	fs.rmdir(OLD_PATH);
}

localStorage.setItem(MV_LOCK, '1');